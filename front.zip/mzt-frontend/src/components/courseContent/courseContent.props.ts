interface CourseContentProps {
    courseId: string;
}

export default CourseContentProps;