interface CoursePromoProps {
    name: string;
    courseId: string;
}

export default CoursePromoProps;