import SignUpForm from "../../components/signupForm/SignUpForm.tsx";

export const RegistrationPage = () => {
    return (
        <SignUpForm/>
    );
};