import {LoginForm} from "../../components/loginForm/loginForm.tsx";

export const LoginPage = () => {
    return (
        <LoginForm/>
    );
};