export interface Lesson {
    lesson_id: string;
    course_id: string;
    title: string;
    summery: string;
    video_url: string;
    text: string;
}