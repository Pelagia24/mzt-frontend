interface Event {
    course_id: string;
    description: string;
    event_date: string;
    event_id: string;
    title: string;
    secret_info: string;
}

export default Event